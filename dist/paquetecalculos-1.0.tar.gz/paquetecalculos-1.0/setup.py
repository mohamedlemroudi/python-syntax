from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Mohamed Lemroudi",
    author_email="mlemroudi700@gmail.com",
    packages=["calculos","calculos.redondeo_potencia"]
)

# python stup.py sdist -> paquete distribuido