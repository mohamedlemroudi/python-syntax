def potencia(base, exponente):
    print("El resultado de la potència es: ", pow(base, exponente))

def redondear(numero):
    print("El resultado de redondear es: ", round(numero))
